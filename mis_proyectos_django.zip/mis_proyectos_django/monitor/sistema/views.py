import psutil
import platform
from django.shortcuts import render

def info_sistema(request):
    cpu = psutil.cpu_percent(interval=1)
    memoria = psutil.virtual_memory().percent
    disco = psutil.disk_usage('/').percent
    sistema = platform.system() + " " + platform.release()

    datos = {
        'cpu': cpu,
        'memoria': memoria,
        'disco': disco,
        'sistema': sistema,
    }

    return render(request, 'sistema/monitor.html', datos)
